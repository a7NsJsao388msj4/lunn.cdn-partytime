import os, sys, io, json, shutil
from tkinter import *
from tkinter import filedialog
import tkinter
from bin import Utils
import subprocess
from colorama import Fore, Style
import logging

print(f'''


  /$$$$$$            /$$                                         /$$      /$$                  
 /$$__  $$          | $$                                        | $$     | $$                  
| $$  \ $$/$$   /$$/$$$$$$   /$$$$$$ /$$$$$$/$$$$  /$$$$$$  /$$$$$$$ /$$$$$$$ /$$$$$$  /$$$$$$ 
| $$$$$$$| $$  | $|_  $$_/  /$$__  $| $$_  $$_  $$/$$__  $$/$$__  $$/$$__  $$/$$__  $$/$$__  $$
| $$__  $| $$  | $$ | $$   | $$  \ $| $$ \ $$ \ $| $$  \ $| $$  | $| $$  | $| $$$$$$$| $$  \__/
| $$  | $| $$  | $$ | $$ /$| $$  | $| $$ | $$ | $| $$  | $| $$  | $| $$  | $| $$_____| $$      
| $$  | $|  $$$$$$/ |  $$$$|  $$$$$$| $$ | $$ | $|  $$$$$$|  $$$$$$|  $$$$$$|  $$$$$$| $$      
|/$$  |__/\______/   \___//$$______/|__/ |__/ |__/\______/ \_______/\_______/\_______|__/      
| $$                     | $$                                                                  
| $$$$$$$ /$$   /$$      | $$/$$   /$$/$$$$$$$ /$$$$$$$                                        
| $$__  $| $$  | $$      | $| $$  | $| $$__  $| $$__  $$                                       
| $$  \ $| $$  | $$      | $| $$  | $| $$  \ $| $$  \ $$                                       
| $$  | $| $$  | $$      | $| $$  | $| $$  | $| $$  | $$                                       
| $$$$$$$|  $$$$$$$      | $|  $$$$$$| $$  | $| $$  | $$                                       
|_______/ \____  $$      |__/\______/|__/  |__|__/  |__/                                       
          /$$  | $$                                                                            
         |  $$$$$$/                                                                            
          \______/  

This JDU Automodder only works with WiiU, NX, PS4 (ORBIS), PS5 (PROSPERO) and PC. This code don´t support offline mainscenes

PLEASE, DON´T SHARE THIS CODE WITH ANYONE!
          
''')          

mapName = str(input('mapName: '))
try:
    coachCount = int(input("coachCount: "))
except ValueError:
    print("use numbers")
    exit()

platform = str(input('Platform (WIIU / NX / ORBIS / PROSPERO / PC - in uppercase letters): '))

main = os.getcwd()
main_jdu_folder = f"{main}/output/jdu/maps/{mapName}/{mapName}_MAIN_SCENE_{platform}"

# Basic Config 
logging.basicConfig(level=logging.INFO)

# Mainscene Maker
def mainscenegen(mapName= str, coachCount= int, platform= str):
   global main_jdu_folder
output_folder_cache = f"{main_jdu_folder}/{mapName.lower()}_main_scene_{platform.lower()}/cache/itf_cooked/{platform.lower()}/world/maps/{mapName.lower()}/"
output_folder_world = f"{main_jdu_folder}/{mapName.lower()}_main_scene_{platform.lower()}/world/maps/{mapName.lower()}/"
    
# Main Folder
os.makedirs(main_jdu_folder, exist_ok=True)

# Atlas Container File
with open(f"{main_jdu_folder}/atlascontainer.ckd", "wb") as archive:  
    archive.write(
        b'\x00\x00\x00\x00\x00\x00\x00\x00'
    )
    
# DLC Descripter File
with open(f"{main_jdu_folder}/dlcdescriptor.ckd", "wb") as archive:  
    archive.write(
        b'\x4A\x44\x4C\x43\x00\x00\x00\x02\x00\x00\x00\x0A\x6D\x61\x70\x63\x6F\x6E\x74\x65\x6E\x74\x00\x00\x00\x13' + '{mapName.lower()}_main_scene'.encode()
    )
    
# SGS Container File
with open(f"{main_jdu_folder}/sgsconteiner.ckd", "w") as archive:
    archive.write(f'''S{{"version":0,"sgsMap":{{"__class":"SceneConfigManager::SgsKey","Keys":{{"world/maps/{mapName.lower()}/{mapName.lower()}_main_scene.isc":{{"__class":"JD_MapSceneConfig","Pause_Level":6,"name":"","type":1,"musicscore":2,"soundContext":"","hud":0,"phoneTitleLocId":4294967295,"phoneImage":""}}}}}}}}''')
    
    # Cache Folder
    
    # Audio folder
    os.makedirs(f'{output_folder_cache}/audio', exist_ok=True)
    
# Stape file
with open(f'{output_folder_cache}/audio/{mapName.lower()}.stape.ckd', "w") as archive:
    archive.write(f'''{{"__class":"Tape","Clips":[],"TapeClock":0,"TapeBarCount":1,"FreeResourcesAfterPlay":0,"MapName":"{mapName}"}}''')

# Audio ISC file
with open(f'{output_folder_cache}/audio/{mapName.lower()}_audio.isc.ckd', "w") as archive: 
    archive.write(f'''
<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<Scene ENGINE_VERSION="253653" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
		<ACTORS NAME="Actor">
			<Actor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="MusicTrack" MARKER="" POS2D="1.125962 -0.418641" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/audio/{mapName.lower()}_musictrack.tpl">
				<COMPONENTS NAME="MusicTrackComponent">
					<MusicTrackComponent />
				</COMPONENTS>
			</Actor>
		</ACTORS>
		<ACTORS NAME="Actor">
			<Actor RELATIVEZ="0.000001" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_sequence" MARKER="" POS2D="-0.006158 -0.006158" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/audio/{mapName.lower()}_sequence.tpl">
				<COMPONENTS NAME="TapeCase_Component">
					<TapeCase_Component />
				</COMPONENTS>
			</Actor>
		</ACTORS>
		<sceneConfigs>
			<SceneConfigs activeSceneConfig="0" />
		</sceneConfigs>
	</Scene>
</root>''')

# Sequence Template file
with open(f'{output_folder_cache}/audio/{mapName.lower()}_sequence.tpl.ckd', "w") as archive: 
    archive.write(f'''{{"__class":"Actor_Template","WIP":0,"LOWUPDATE":0,"UPDATE_LAYER":0,"PROCEDURAL":0,"STARTPAUSED":0,"FORCEISENVIRONMENT":0,"COMPONENTS":[{{"__class":"TapeCase_Template","TapesRack":[{{"__class":"TapeGroup","Entries":[{{"__class":"TapeEntry","Label":"TML_Sequence","Path":"world/maps/{mapName}/audio/{mapName}.stape"}}]}}]}}]}}''')
    
    # End of Audio Folder
    
    # Autodance Folder
    os.makedirs(f'{output_folder_cache}/autodance', exist_ok=True)
    
# Autodance Actor File
with open(f'{output_folder_cache}/autodance/{mapName.lower()}_autodance.act.ckd', "wb") as archive:  
    archive.write(
        b'\x00\x00\x00\x01\x00\x00\x00\x00\x3F\x80\x00\x00\x3F\x80\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xFF\xFF'
        b'\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x18' +
        f'{mapName.lower()}_autodance.tpl'.encode() +
        b'\x00\x00\x00\x20world/maps/' +
        f'{mapName.lower()}'.encode() +
        b'/autodance\x7A\xDC\xC4\x8C\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x67\xB8\xBB\x77'
    )
    
# Autodance ISC file
with open(f'{output_folder_cache}/autodance/{mapName.lower()}_autodance.isc.ckd', "w") as archive: 
    archive.write(f'''
<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<Scene ENGINE_VERSION="253653" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
		<ACTORS NAME="Actor">
			<Actor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_autodance" MARKER="" POS2D="-0.006150 -0.003075" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/autodance/{mapName.lower()}_autodance.tpl">
				<COMPONENTS NAME="JD_AutodanceComponent">
					<JD_AutodanceComponent />
				</COMPONENTS>
			</Actor>
		</ACTORS>
		<sceneConfigs>
			<SceneConfigs activeSceneConfig="0" />
		</sceneConfigs>
	</Scene>
</root>''')

# Autodance Template File
with open(f'{output_folder_cache}/autodance/{mapName.lower()}_autodance.tpl.ckd', "w") as archive:  
    archive.write(f'''{{"__class":"Actor_Template","WIP":0,"LOWUPDATE":0,"UPDATE_LAYER":0,"PROCEDURAL":0,"STARTPAUSED":0,"FORCEISENVIRONMENT":0,"COMPONENTS":[{{"__class":"JD_AutodanceComponent_Template","song":"{mapName}","autodanceData":{{"__class":"JD_AutodanceData","recording_structure":{{"__class":"JD_AutodanceRecordingStructure","records":[{{"__class":"Record","Start":88,"Duration":16}},{{"__class":"Record","Start":136,"Duration":8}},{{"__class":"Record","Start":188,"Duration":8}},{{"__class":"Record","Start":252,"Duration":16}}]}}, "video_structure":{{"__class":"JD_AutodanceVideoStructure","SongStartPosition":244,"Duration":32,"ThumbnailTime":0,"FadeOutDuration":3,"GroundPlanePath":"invalid ","FirstLayerTripleBackgroundPath":"invalid ","SecondLayerTripleBackgroundPath":"invalid ","ThirdLayerTripleBackgroundPath":"invalid ","playback_events":[{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":0,"StartTime":244,"Duration":1,"Speed":1}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":0,"StartTime":245,"Duration":1,"Speed":1}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":0,"StartTime":246,"Duration":1,"Speed":1}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":0,"StartTime":247,"Duration":1,"Speed":1}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":3,"StartTime":248,"Duration":0.500000,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":3,"StartTime":248.500000,"Duration":0.500000,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":3,"StartTime":249,"Duration":0.500000,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":3,"StartTime":249.500000,"Duration":0.500000,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":1,"StartClip":0,"StartTime":250,"Duration":1,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":1,"StartClip":1,"StartTime":251,"Duration":1,"Speed":4}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":5,"StartTime":252,"Duration":1,"Speed":1.500000}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":5,"StartTime":253,"Duration":1,"Speed":1.500000}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":6,"StartTime":254,"Duration":2,"Speed":1.800000}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":6,"StartTime":256,"Duration":0.500000,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":6,"StartTime":256.500000,"Duration":0.500000,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":6,"StartTime":257,"Duration":0.500000,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":6,"StartTime":257.500000,"Duration":0.500000,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":6,"StartTime":258,"Duration":0.500000,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":7,"StartTime":258.500000,"Duration":1.500000,"Speed":1.500000}},{{"__class":"PlaybackEvent","ClipNumber":2,"StartClip":0,"StartTime":260,"Duration":1,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":1,"StartClip":2,"StartTime":261,"Duration":1,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":1,"StartClip":2,"StartTime":262,"Duration":1,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":1,"StartClip":2,"StartTime":263,"Duration":1,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":3,"StartClip":0,"StartTime":264,"Duration":1.500000,"Speed":3}},{{"__class":"PlaybackEvent","ClipNumber":3,"StartClip":3,"StartTime":265.500000,"Duration":1.500000,"Speed":-3}},{{"__class":"PlaybackEvent","ClipNumber":3,"StartClip":1.500000,"StartTime":267,"Duration":1,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":3,"StartClip":2.200000,"StartTime":268,"Duration":1,"Speed":3}},{{"__class":"PlaybackEvent","ClipNumber":2,"StartClip":0,"StartTime":269,"Duration":2,"Speed":3}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":0,"StartTime":271,"Duration":1,"Speed":1}},{{"__class":"PlaybackEvent","ClipNumber":3,"StartClip":4,"StartTime":272,"Duration":2,"Speed":2}},{{"__class":"PlaybackEvent","ClipNumber":0,"StartClip":0,"StartTime":274,"Duration":1,"Speed":1}},{{"__class":"PlaybackEvent","ClipNumber":3,"StartClip":3,"StartTime":275,"Duration":1,"Speed":5}}], "background_effect":{{"__class":"AutoDanceFxDesc","Opacity":1,"ColorLow":{{"__class":"GFX_Vector4","x":0,"y":0,"z":0,"w":1}},...}}}}}}}}]}}}}''')
    
    # End of Autodance Folder
    
    # Cinematics Folder
    os.makedirs(f'{output_folder_cache}/cinematics', exist_ok=True)
    
# Cinematics ISC File
with open(f'{output_folder_cache}/cinematics/{mapName.lower()}_cine.isc.ckd', "w") as archive:
    archive.write(f'''
<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<Scene ENGINE_VERSION="253653" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
		<ACTORS NAME="Actor">
			<Actor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_MainSequence" MARKER="" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/cinematics/{mapName.lower()}_mainsequence.tpl">
				<COMPONENTS NAME="MasterTape">
					<MasterTape />
				</COMPONENTS>
			</Actor>
		</ACTORS>
		<sceneConfigs>
			<SceneConfigs activeSceneConfig="0" />
		</sceneConfigs>
	</Scene>
</root>''')

# Mainsequence Actor File
with open(f'{output_folder_cache}/cinematics/{mapName.lower()}_mainsequence.act.ckd', "wb") as archive:  
    archive.write(
        b'\x00\x00\x00\x01\x00\x00\x00\x00\x3F\x80\x00\x00\x3F\x80\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x19' +
        f'{mapName.lower()}_mainsequence.tpl'.encode() +
        b'\x00\x00\x00\x1Fworld/maps/' +
        f'{mapName.lower()}'.encode() +
        b'/cinematics\x2F\x78\x26\x20\x88\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x67\xB8\xBB\x77'
    )
    
# Mainsequence Tape File
with open(f'{output_folder_cache}/cinematics/{mapName.lower()}_mainsequence.tape.ckd', "w") as archive:
    archive.write(f'''{{"__class":"Tape","Clips":[],"TapeClock":0,"TapeBarCount":1,"FreeResourcesAfterPlay":0,"MapName":"{mapName}"}}''')
    
# Mainsequence Template File
with open(f'{output_folder_cache}/cinematics/{mapName.lower()}_mainsequence.tpl.ckd', "w") as archive:  
    archive.write(f'''{{"__class":"Actor_Template","WIP":0,"LOWUPDATE":0,"UPDATE_LAYER":0,"PROCEDURAL":0,"STARTPAUSED":0,"FORCEISENVIRONMENT":0,"COMPONENTS":[{{"__class":"MasterTape_Template","TapesRack":[{{"__class":"TapeGroup","Entries":[{{"__class":"TapeEntry","Label":"master","Path":"world/maps/{mapName.lower()}/cinematics/{mapName.lower()}_mainsequence.tape"}}]}}]}}]}}''')
    
    # End of Cinematics Folder
    
    # Graph Folder
    os.makedirs(f'{output_folder_cache}/graph', exist_ok=True)
    
# Graph ISC File
with open(f'{output_folder_cache}/graph/{mapName.lower()}_graph.isc.ckd', "w") as archive:
    archive.write(f'''
<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<Scene ENGINE_VERSION="253653" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
		<ACTORS NAME="Actor">
			<Actor RELATIVEZ="10.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="Camera_JD_Dummy" MARKER="" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/tpl_emptyactor.tpl" />
		</ACTORS>
		<sceneConfigs>
			<SceneConfigs activeSceneConfig="0" />
		</sceneConfigs>
	</Scene>
</root>''')

    # End of Graph Folder
    
    # Timeline Folder
    os.makedirs(f'{output_folder_cache}/timeline', exist_ok=True)
    
    # Pictos Folder
    os.makedirs(f'{output_folder_cache}/timeline/pictos', exist_ok=True)
    
# Timeline ISC File
with open(f'{output_folder_cache}/timeline/{mapName.lower()}_tml.isc.ckd', "w") as archive:
    archive.write(f'''
<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<Scene ENGINE_VERSION="253653" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
		<ACTORS NAME="Actor">
			<Actor RELATIVEZ="0.000001" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_tml_dance" MARKER="" POS2D="-1.157740 0.006158" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/timeline/{mapName.lower()}_tml_dance.tpl">
				<COMPONENTS NAME="TapeCase_Component">
					<TapeCase_Component />
				</COMPONENTS>
			</Actor>
		</ACTORS>
		<ACTORS NAME="Actor">
			<Actor RELATIVEZ="0.000001" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_tml_karaoke" MARKER="" POS2D="-1.157740 0.006158" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/timeline/{mapName.lower()}_tml_karaoke.tpl">
				<COMPONENTS NAME="TapeCase_Component">
					<TapeCase_Component />
				</COMPONENTS>
			</Actor>
		</ACTORS>
		<sceneConfigs>
			<SceneConfigs activeSceneConfig="0" />
		</sceneConfigs>
	</Scene>
</root>''')

# Timeline Dance Template File
with open(f'{output_folder_cache}/timeline/{mapName.lower()}_tml_dance.tpl.ckd', "w") as archive:
    archive.write(f'''{{"__class":"Actor_Template","WIP":0,"LOWUPDATE":0,"UPDATE_LAYER":0,"PROCEDURAL":0,"STARTPAUSED":0,"FORCEISENVIRONMENT":0,"COMPONENTS":[{{"__class":"TapeCase_Template","TapesRack":[{{"__class":"TapeGroup","Entries":[{{"__class":"TapeEntry","Label":"TML_Motion","Path":"world/maps/{mapName.lower()}/timeline/{mapName.lower()}_tml_dance.dtape"}}]}}]}}]}}''')
    
# Timeline Karaoke Template File
with open(f'{output_folder_cache}/timeline/{mapName.lower()}_tml_karaoke.tpl.ckd', "w") as archive:
    archive.write(f'''{{"__class":"Actor_Template","WIP":0,"LOWUPDATE":0,"UPDATE_LAYER":0,"PROCEDURAL":0,"STARTPAUSED":0,"FORCEISENVIRONMENT":0,"COMPONENTS":[{{"__class":"TapeCase_Template","TapesRack":[{{"__class":"TapeGroup","Entries":[{{"__class":"TapeEntry","Label":"TML_karaoke","Path":"world/maps/{mapName.lower()}/timeline/{mapName.lower()}_tml_karaoke.ktape"}}]}}]}}]}}''')
    
# Timeline Dance Actor File
with open(f'{output_folder_cache}/timeline/{mapName.lower()}_tml_dance.act.ckd', "wb") as archive:  
    archive.write(
        b'\x00\x00\x00\x01\x00\x00\x00\x00\x3F\x80\x00\x00\x3F\x80\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x16' +
        f'{mapName.lower()}_tml_dance.tpl'.encode() +
        b'\x00\x00\x00\x1Dworld/maps/' +
        f'{mapName.lower()}'.encode() +
        b'/timeline\x2F\x59\xC9\xDD\x1F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x23\x1F\x27\xDE'
    )
    
# Timeline Karaoke Actor File
with open(f'{output_folder_cache}/timeline/{mapName.lower()}_tml_karaoke.act.ckd', "wb") as archive:  
    archive.write(
        b'\x00\x00\x00\x01\x00\x00\x00\x00\x3F\x80\x00\x00\x3F\x80\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x18' +
        f'{mapName.lower()}_tml_karaoke.tpl'.encode() +
        b'\x00\x00\x00\x1Dworld/maps/' +
        f'{mapName.lower()}'.encode() +
        b'/timeline\x2F\x83\x84\x4E\x29\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x23\x1F\x27\xDE'
    )
    
    # End of Timeline Folder
    
    # VideoCoach Folder
    os.makedirs(f'{output_folder_cache}/videoscoach', exist_ok=True)
    
# Video ISC File
with open(f'{output_folder_cache}/videoscoach/{mapName.lower()}_video.isc.ckd', "w") as archive:
        archive.write(f'''
<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
    <Scene ENGINE_VERSION="253653" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
        <ACTORS NAME="Actor">
            <Actor RELATIVEZ="-1.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="VideoScreen" MARKER="" POS2D="0.000000 -4.500000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/_common/videoscreen/video_player_main.tpl">
                <COMPONENTS NAME="PleoComponent">
                    <PleoComponent video="world/maps/{mapName.lower()}/videoscoach/{mapName.lower()}.webm" dashMPD="world/maps/{mapName.lower()}/videoscoach/{mapName.lower()}.mpd" channelID="" />
                </COMPONENTS>
            </Actor>
        </ACTORS>
        <ACTORS NAME="Actor">
            <Actor RELATIVEZ="0.000000" SCALE="3.941238 2.220000" xFLIPPED="0" USERFRIENDLY="VideoOutput" MARKER="" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/_common/videoscreen/video_output_main.tpl">
                <COMPONENTS NAME="PleoTextureGraphicComponent">
                    <PleoTextureGraphicComponent colorComputerTagId="0" renderInTarget="0" disableLight="0" disableShadow="4294967295" AtlasIndex="0" customAnchor="0.000000 0.000000" SinusAmplitude="0.000000 0.000000 0.000000" SinusSpeed="1.000000" AngleX="0.000000" AngleY="0.000000" channelID="">
                        <PrimitiveParameters>
                            <GFXPrimitiveParam colorFactor="1.000000 1.000000 1.000000 1.000000">
                                <ENUM NAME="gfxOccludeInfo" SEL="0" />
                            </GFXPrimitiveParam>
                        </PrimitiveParameters>
                        <ENUM NAME="anchor" SEL="1" />
                        <material>
                            <GFXMaterialSerializable ATL_Channel="0" ATL_Path="" shaderPath="world/_common/matshader/pleofullscreen.msh" stencilTest="0" alphaTest="0" alphaRef="0">
                                <textureSet>
                                    <GFXMaterialTexturePathSet diffuse="" back_light="" normal="" separateAlpha="" diffuse_2="" back_light_2="" anim_impostor="" diffuse_3="" diffuse_4="" />
                                </textureSet>
                                <materialParams>
                                    <GFXMaterialSerializableParam Reflector_factor="0.000000" />
                                </materialParams>
                            </GFXMaterialSerializable>
                        </material>
                        <ENUM NAME="oldAnchor" SEL="1" />
                    </PleoTextureGraphicComponent>
                </COMPONENTS>
            </Actor>
        </ACTORS>
        <sceneConfigs>
            <SceneConfigs activeSceneConfig="0" />
        </sceneConfigs>
    </Scene>
</root>''')

# Video Player Main Actor File
with open(f'{output_folder_cache}/videoscoach/video_player_main.act.ckd', "wb") as archive:  
    archive.write(
        b'\x00\x00\x00\x01\x00\x00\x00\x00\x3F\x80\x00\x00\x3F\x80\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x15'
        b'\x76\x69\x64\x65\x6F\x5F\x70\x6C\x61\x79\x65\x72\x5F\x6D\x61\x69'
        b'\x6E\x2E\x74\x70\x6C\x00\x00\x00\x1A\x77\x6F\x72\x6C\x64\x2F\x5F'
        b'\x63\x6F\x6D\x6D\x6F\x6E\x2F\x76\x69\x64\x65\x6F\x73\x63\x72\x65'
        b'\x65\x6E\x2F\xF5\xD5\xE8\xF2\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x01\x12\x63\xDA\xD9\x00\x00\x00\x0D' +
        f'{mapName.lower()}.webm'.encode() +
        b'\x00\x00\x00\x1Dworld/maps/' +
        f'{mapName.lower()}'.encode() +
        b'/videoscoach\x2F\x2B\x90\x28\x58\x00\x00\x00\x00\x00\x00\x00\x0B'
        + f'{mapName.lower()}.mpd'.encode() +
        b'\x00\x00\x00\x1Fworld/maps/' +
        f'{mapName.lower()}'.encode() +
        b'/videoscoach\x20\xF4\xD7\xE7\x00\x00\x00\x00\x00\x00\x00'
    )
    
# MPDs HD/SD File
if platform in ["ORBIS", "DURANGO", "PROSPERO"]:
   with open(f"{output_folder_cache}/videoscoach/{mapName.lower()}.hd.mpd.ckd", "wb") as archive:
        archive.write(
            b'\x00\x00\x00\x01\x00\x43\x24\x85\x1F\x3F\x80\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x43\x24\x85\x1F\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x0A\x76\x69\x64\x65\x6F\x2F\x77\x65\x62\x6D\x00\x00\x00\x03\x76\x70\x38\x00\x00\x07\x80\x00\x00\x04\x38\x00\x00\x00\x00\x00\x00\x00\x01\x01\x01\x00\x00x\x00\x08\x00\x00\x00\x00\x00\x2B\xE0\x91\x00\x00\x00\x23' +
            f"jmcs://jd-contents/{mapName}/{mapName}_LOW.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x97\x00\x00\x02\x97\x00\x00\x0D\x7F\x00\x00\x00\x01\x00\x59\x6C\xDA\x00\x00\x00\x23' +
            f"jmcs://jd-contents/{mapName}/{mapName}_MID.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x97\x00\x00\x02\x97\x00\x00\x0D\xBB\x00\x00\x00\x02\x00\xBE\xC2\xD4\x00\x00\x00x\x24' +
            f"jmcs://jd-contents/{mapName}/{mapName}_HIGH.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x9C\x00\x00\x02\x9C\x00\x00\x0D\xDB\x00\x00\x00\x03\x00\xCA\x4C\x8E\x00\x00\x00\x25' +
            f"jmcs://jd-contents/{mapName}/{mapName}_ULTRA.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x9C\x00\x00\x02\x9C\x00\x00\x0D\xDC\x00\x00\x00\x04\x00\x2B\xE1\xE0\x00\x00\x00\x26' +
            f"jmcs://jd-contents/{mapName}/{mapName}_LOW.hd.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x97\x00\x00\x02\x97\x00\x00\x0D\x81\x00\x00\x00\x05\x00\x59\x6B\x1A\x00\x00\x00' +
            f"jmcs://jd-contents/{mapName}/{mapName}_MID.hd.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x97\x00\x00\x02\x97\x00\x00\x0D\xBC\x00\x00\x00\x06\x00\xC8\x67\x3E\x00\x00\x00\x27' +
            f"jmcs://jd-contents/{mapName}/{mapName}_HIGH.hd.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x9C\x00\x00\x02\x9C\x00\x00\x0D\xDB\x00\x00\x00\x07\x01\x21\x90\x31\x00\x00\x00\x28' +
            f"jmcs://jd-contents/{mapName}/{mapName}_ULTRA.hd.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x97\x00\x00\x02\x97\x00\x00\x0D\xEA'
        )
elif platform in ["PC", "NX", "WIIU"]:
   with open(f"{output_folder_cache}/videoscoach/{mapName.lower()}.mpd.ckd", "wb") as archive:
       archive.write(
            b'\x00\x00\x00\x01\x00\x43\x24\x85\x1F\x3F\x80\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x43\x24\x85\x1F\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x0A\x76\x69\x64\x65\x6F\x2F\x77\x65\x62\x6D\x00\x00\x00\x03\x76\x70\x38\x00\x00\x07\x80\x00\x00\x04\x38\x00\x00\x00\x00\x00\x00\x00\x01\x01\x01\x00\x00x\x00\x08\x00\x00\x00\x00\x00\x2B\xE0\x91\x00\x00\x00\x23' +
            f"jmcs://jd-contents/{mapName}/{mapName}_LOW.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x97\x00\x00\x02\x97\x00\x00\x0D\x7F\x00\x00\x00\x01\x00\x59\x6C\xDA\x00\x00\x00\x23' +
            f"jmcs://jd-contents/{mapName}/{mapName}_MID.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x97\x00\x00\x02\x97\x00\x00\x0D\xBB\x00\x00\x00\x02\x00\xBE\xC2\xD4\x00\x00\x00x\x24' +
            f"jmcs://jd-contents/{mapName}/{mapName}_HIGH.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x9C\x00\x00\x02\x9C\x00\x00\x0D\xDB\x00\x00\x00\x03\x00\xCA\x4C\x8E\x00\x00\x00\x25' +
            f"jmcs://jd-contents/{mapName}/{mapName}_ULTRA.webm".encode() +
            b'\x00\x00\x00\x00\x00\x00\x02\x9C\x00\x00\x02\x9C\x00\x00\x0D\xDC'
        )
    
    # End of VideosCoach Folder
    
    # Main Cache Folder
    
# MainScene ISC File
with open (f'{output_folder_cache}/{mapName.lower()}_main_scene.isc.ckd', "w") as archive:
    archive.write('''
<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<Scene ENGINE_VERSION="272933" GRIDUNIT="2.000000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
		<PLATFORM_FILTER>
			<TargetFilterList platform="WII">
				<objects VAL="{mapName}_AUTODANCE" />
			</TargetFilterList>
		</PLATFORM_FILTER>
		<ACTORS NAME="SubSceneActor">
			<SubSceneActor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_AUDIO" MARKER="" isEnabled="1" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/subscene.tpl" RELATIVEPATH="world/maps/{mapName.lower()}/audio/{mapName.lower()}_audio.isc" EMBED_SCENE="1" IS_SINGLE_PIECE="0" ZFORCED="1" DIRECT_PICKING="1" IGNORE_SAVE="0">
				<ENUM NAME="viewType" SEL="2" />
				<SCENE>
					<Scene ENGINE_VERSION="272933" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="MusicTrack" MARKER="" isEnabled="1" POS2D="1.125962 -0.418641" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/audio/{mapName.lower()}_musictrack.tpl">
								<COMPONENTS NAME="MusicTrackComponent">
									<MusicTrackComponent />
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000001" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_sequence" MARKER="" isEnabled="1" POS2D="-0.006158 -0.006158" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/audio/{mapName.lower()}_sequence.tpl">
								<COMPONENTS NAME="TapeCase_Component">
									<TapeCase_Component />
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<sceneConfigs>
							<SceneConfigs activeSceneConfig="0" />
						</sceneConfigs>
					</Scene>
				</SCENE>
			</SubSceneActor>
		</ACTORS>
		<ACTORS NAME="SubSceneActor">
			<SubSceneActor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_CINE" MARKER="" isEnabled="1" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/subscene.tpl" RELATIVEPATH="world/maps/{mapName.lower()}/cinematics/{mapName.lower()}_cine.isc" EMBED_SCENE="1" IS_SINGLE_PIECE="0" ZFORCED="1" DIRECT_PICKING="1" IGNORE_SAVE="0">
				<ENUM NAME="viewType" SEL="2" />
				<SCENE>
					<Scene ENGINE_VERSION="272933" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_MainSequence" MARKER="" isEnabled="1" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/cinematics/{mapName.lower()}_mainsequence.tpl">
								<COMPONENTS NAME="MasterTape">
									<MasterTape />
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<sceneConfigs>
							<SceneConfigs activeSceneConfig="0" />
						</sceneConfigs>
					</Scene>
				</SCENE>
			</SubSceneActor>
		</ACTORS>
		<ACTORS NAME="SubSceneActor">
			<SubSceneActor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_GRAPH" MARKER="" isEnabled="1" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/subscene.tpl" RELATIVEPATH="world/maps/{mapName.lower()}/graph/{mapName.lower()}_graph.isc" EMBED_SCENE="1" IS_SINGLE_PIECE="0" ZFORCED="1" DIRECT_PICKING="1" IGNORE_SAVE="0">
				<ENUM NAME="viewType" SEL="2" />
				<SCENE>
					<Scene ENGINE_VERSION="272933" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="10.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="Camera_JD_Dummy" MARKER="" isEnabled="1" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/tpl_emptyactor.tpl" />
						</ACTORS>
						<sceneConfigs>
							<SceneConfigs activeSceneConfig="0" />
						</sceneConfigs>
					</Scene>
				</SCENE>
			</SubSceneActor>
		</ACTORS>
		<ACTORS NAME="SubSceneActor">
			<SubSceneActor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_TML" MARKER="" isEnabled="1" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/subscene.tpl" RELATIVEPATH="world/maps/{mapName.lower()}/timeline/{mapName.lower()}_tml.isc" EMBED_SCENE="1" IS_SINGLE_PIECE="0" ZFORCED="1" DIRECT_PICKING="1" IGNORE_SAVE="0">
				<ENUM NAME="viewType" SEL="2" />
				<SCENE>
					<Scene ENGINE_VERSION="272933" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000001" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_tml_dance" MARKER="" isEnabled="1" POS2D="-1.157740 0.006158" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/timeline/{mapName.lower()}_tml_dance.tpl">
								<COMPONENTS NAME="TapeCase_Component">
									<TapeCase_Component />
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000001" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_tml_karaoke" MARKER="" isEnabled="1" POS2D="-1.157740 0.006158" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/timeline/{mapName.lower()}_tml_karaoke.tpl">
								<COMPONENTS NAME="TapeCase_Component">
									<TapeCase_Component />
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<sceneConfigs>
							<SceneConfigs activeSceneConfig="0" />
						</sceneConfigs>
					</Scene>
				</SCENE>
			</SubSceneActor>
		</ACTORS>
		<ACTORS NAME="SubSceneActor">
			<SubSceneActor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_VIDEO" MARKER="" isEnabled="1" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/subscene.tpl" RELATIVEPATH="world/maps/{mapName.lower()}/videoscoach/{mapName.lower()}_video.isc" EMBED_SCENE="1" IS_SINGLE_PIECE="0" ZFORCED="1" DIRECT_PICKING="1" IGNORE_SAVE="0">
				<ENUM NAME="viewType" SEL="2" />
				<SCENE>
					<Scene ENGINE_VERSION="272933" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="-1.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="VideoScreen" MARKER="" isEnabled="1" POS2D="0.000000 -4.500000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/_common/videoscreen/video_player_main.tpl">
								<COMPONENTS NAME="PleoComponent">
									<PleoComponent video="world/maps/{mapName.lower()}/videoscoach/{mapName.lower()}.webm" dashMPD="world/maps/{mapName.lower()}/videoscoach/{mapName.lower()}.mpd" channelID="" />
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="3.941238 2.220000" xFLIPPED="0" USERFRIENDLY="VideoOutput" MARKER="" isEnabled="1" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/_common/videoscreen/video_output_main.tpl">
								<COMPONENTS NAME="PleoTextureGraphicComponent">
									<PleoTextureGraphicComponent colorComputerTagId="0" renderInTarget="0" disableLight="0" disableShadow="4294967295" AtlasIndex="0" customAnchor="0.000000 0.000000" SinusAmplitude="0.000000 0.000000 0.000000" SinusSpeed="1.000000" AngleX="0.000000" AngleY="0.000000" channelID="">
										<PrimitiveParameters>
											<GFXPrimitiveParam colorFactor="1.000000 1.000000 1.000000 1.000000">
												<ENUM NAME="gfxOccludeInfo" SEL="0" />
											</GFXPrimitiveParam>
										</PrimitiveParameters>
										<ENUM NAME="anchor" SEL="1" />
										<material>
											<GFXMaterialSerializable ATL_Channel="0" ATL_Path="" shaderPath="world/_common/matshader/pleofullscreen.msh" stencilTest="0" alphaTest="4294967295" alphaRef="4294967295">
												<textureSet>
													<GFXMaterialTexturePathSet diffuse="" back_light="" normal="" separateAlpha="" diffuse_2="" back_light_2="" anim_impostor="" diffuse_3="" diffuse_4="" />
												</textureSet>
												<materialParams>
													<GFXMaterialSerializableParam Reflector_factor="0.000000" />
												</materialParams>
											</GFXMaterialSerializable>
										</material>
										<ENUM NAME="oldAnchor" SEL="1" />
									</PleoTextureGraphicComponent>
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<sceneConfigs>
							<SceneConfigs activeSceneConfig="0" />
						</sceneConfigs>
					</Scene>
				</SCENE>
			</SubSceneActor>
		</ACTORS>
		<ACTORS NAME="Actor">
			<Actor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName} : Template Artist - Template Title&#10;JDVer = 5, ID = 842776738, Type = 1 (Flags 0x00000000), NbCoach = 2, Difficulty = 2" MARKER="" isEnabled="1" POS2D="-3.531976 -1.485322" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/songdesc.tpl">
				<COMPONENTS NAME="JD_SongDescComponent">
					<JD_SongDescComponent />
				</COMPONENTS>
			</Actor>
		</ACTORS>
		<ACTORS NAME="SubSceneActor">
			<SubSceneActor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_menuart" MARKER="" isEnabled="1" POS2D="0.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/subscene.tpl" RELATIVEPATH="world/maps/{mapName.lower()}/menuart/{mapName.lower()}_menuart.isc" EMBED_SCENE="1" IS_SINGLE_PIECE="0" ZFORCED="1" DIRECT_PICKING="1" IGNORE_SAVE="0">
				<ENUM NAME="viewType" SEL="3" />
				<SCENE>
					<Scene ENGINE_VERSION="272933" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="1">
						<PLATFORM_FILTER>
							<TargetFilterList platform="WII">
								<objects VAL="{mapName}_banner_bkg" />
							</TargetFilterList>
						</PLATFORM_FILTER>
						<PLATFORM_FILTER>
							<TargetFilterList platform="PS3">
								<objects VAL="{mapName}_banner_bkg" />
							</TargetFilterList>
						</PLATFORM_FILTER>
						<PLATFORM_FILTER>
							<TargetFilterList platform="X360">
								<objects VAL="{mapName}_banner_bkg" />
							</TargetFilterList>
						</PLATFORM_FILTER>
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="0.300000 0.300000" xFLIPPED="0" USERFRIENDLY="{mapName}_cover_generic" MARKER="" isEnabled="1" POS2D="266.087555 197.629959" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/tpl_materialgraphiccomponent2d.tpl">
								<COMPONENTS NAME="MaterialGraphicComponent">
									<MaterialGraphicComponent colorComputerTagId="0" renderInTarget="0" disableLight="0" disableShadow="4294967295" AtlasIndex="0" customAnchor="0.000000 0.000000" SinusAmplitude="0.000000 0.000000 0.000000" SinusSpeed="1.000000" AngleX="0.000000" AngleY="0.000000">
										<PrimitiveParameters>
											<GFXPrimitiveParam colorFactor="1.000000 1.000000 1.000000 1.000000">
												<ENUM NAME="gfxOccludeInfo" SEL="0" />
											</GFXPrimitiveParam>
										</PrimitiveParameters>
										<ENUM NAME="anchor" SEL="1" />
										<material>
											<GFXMaterialSerializable ATL_Channel="0" ATL_Path="" shaderPath="world/_common/matshader/multitexture_1layer.msh" stencilTest="0" alphaTest="4294967295" alphaRef="4294967295">
												<textureSet>
													<GFXMaterialTexturePathSet diffuse="world/maps/{mapName.lower()}/menuart/textures/{mapName.lower()}_cover_generic.tga" back_light="" normal="" separateAlpha="" diffuse_2="" back_light_2="" anim_impostor="" diffuse_3="" diffuse_4="" />
												</textureSet>
												<materialParams>
													<GFXMaterialSerializableParam Reflector_factor="0.000000" />
												</materialParams>
											</GFXMaterialSerializable>
										</material>
										<ENUM NAME="oldAnchor" SEL="1" />
									</MaterialGraphicComponent>
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="0.300000 0.300000" xFLIPPED="0" USERFRIENDLY="{mapName}_cover_online" MARKER="" isEnabled="1" POS2D="-150.000000 0.000000" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/tpl_materialgraphiccomponent2d.tpl">
								<COMPONENTS NAME="MaterialGraphicComponent">
									<MaterialGraphicComponent colorComputerTagId="0" renderInTarget="0" disableLight="0" disableShadow="4294967295" AtlasIndex="0" customAnchor="0.000000 0.000000" SinusAmplitude="0.000000 0.000000 0.000000" SinusSpeed="1.000000" AngleX="0.000000" AngleY="0.000000">
										<PrimitiveParameters>
											<GFXPrimitiveParam colorFactor="1.000000 1.000000 1.000000 1.000000">
												<ENUM NAME="gfxOccludeInfo" SEL="0" />
											</GFXPrimitiveParam>
										</PrimitiveParameters>
										<ENUM NAME="anchor" SEL="1" />
										<material>
											<GFXMaterialSerializable ATL_Channel="0" ATL_Path="" shaderPath="world/_common/matshader/multitexture_1layer.msh" stencilTest="0" alphaTest="4294967295" alphaRef="4294967295">
												<textureSet>
													<GFXMaterialTexturePathSet diffuse="world/maps/{mapName.lower()}/menuart/textures/{mapName.lower()}_cover_online.tga" back_light="" normal="" separateAlpha="" diffuse_2="" back_light_2="" anim_impostor="" diffuse_3="" diffuse_4="" />
												</textureSet>
												<materialParams>
													<GFXMaterialSerializableParam Reflector_factor="0.000000" />
												</materialParams>
											</GFXMaterialSerializable>
										</material>
										<ENUM NAME="oldAnchor" SEL="1" />
									</MaterialGraphicComponent>
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="0.300000 0.300000" xFLIPPED="0" USERFRIENDLY="{mapName}_cover_albumcoach" MARKER="" isEnabled="1" POS2D="738.106323 359.612030" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/tpl_materialgraphiccomponent2d.tpl">
								<COMPONENTS NAME="MaterialGraphicComponent">
									<MaterialGraphicComponent colorComputerTagId="0" renderInTarget="0" disableLight="0" disableShadow="4294967295" AtlasIndex="0" customAnchor="0.000000 0.000000" SinusAmplitude="0.000000 0.000000 0.000000" SinusSpeed="1.000000" AngleX="0.000000" AngleY="0.000000">
										<PrimitiveParameters>
											<GFXPrimitiveParam colorFactor="1.000000 1.000000 1.000000 1.000000">
												<ENUM NAME="gfxOccludeInfo" SEL="0" />
											</GFXPrimitiveParam>
										</PrimitiveParameters>
										<ENUM NAME="anchor" SEL="6" />
										<material>
											<GFXMaterialSerializable ATL_Channel="0" ATL_Path="" shaderPath="world/_common/matshader/multitexture_1layer.msh" stencilTest="0" alphaTest="4294967295" alphaRef="4294967295">
												<textureSet>
													<GFXMaterialTexturePathSet diffuse="world/maps/{mapName.lower()}/menuart/textures/{mapName.lower()}_cover_albumcoach.tga" back_light="" normal="" separateAlpha="" diffuse_2="" back_light_2="" anim_impostor="" diffuse_3="" diffuse_4="" />
												</textureSet>
												<materialParams>
													<GFXMaterialSerializableParam Reflector_factor="0.000000" />
												</materialParams>
											</GFXMaterialSerializable>
										</material>
										<ENUM NAME="oldAnchor" SEL="6" />
									</MaterialGraphicComponent>
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="0.300000 0.300000" xFLIPPED="0" USERFRIENDLY="{mapName}_cover_albumbkg" MARKER="" isEnabled="1" POS2D="1067.972168 201.986328" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/tpl_materialgraphiccomponent2d.tpl">
								<COMPONENTS NAME="MaterialGraphicComponent">
									<MaterialGraphicComponent colorComputerTagId="0" renderInTarget="0" disableLight="0" disableShadow="4294967295" AtlasIndex="0" customAnchor="0.000000 0.000000" SinusAmplitude="0.000000 0.000000 0.000000" SinusSpeed="1.000000" AngleX="0.000000" AngleY="0.000000">
										<PrimitiveParameters>
											<GFXPrimitiveParam colorFactor="1.000000 1.000000 1.000000 1.000000">
												<ENUM NAME="gfxOccludeInfo" SEL="0" />
											</GFXPrimitiveParam>
										</PrimitiveParameters>
										<ENUM NAME="anchor" SEL="1" />
										<material>
											<GFXMaterialSerializable ATL_Channel="0" ATL_Path="" shaderPath="world/_common/matshader/multitexture_1layer.msh" stencilTest="0" alphaTest="4294967295" alphaRef="4294967295">
												<textureSet>
													<GFXMaterialTexturePathSet diffuse="world/maps/{mapName.lower()}/menuart/textures/{mapName.lower()}_cover_albumbkg.tga" back_light="" normal="" separateAlpha="" diffuse_2="" back_light_2="" anim_impostor="" diffuse_3="" diffuse_4="" />
												</textureSet>
												<materialParams>
													<GFXMaterialSerializableParam Reflector_factor="0.000000" />
												</materialParams>
											</GFXMaterialSerializable>
										</material>
										<ENUM NAME="oldAnchor" SEL="1" />
									</MaterialGraphicComponent>
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="256.000000 128.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_banner_bkg" MARKER="" isEnabled="1" POS2D="1487.410156 -32.732918" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/tpl_materialgraphiccomponent2d.tpl">
								<COMPONENTS NAME="MaterialGraphicComponent">
									<MaterialGraphicComponent colorComputerTagId="0" renderInTarget="0" disableLight="0" disableShadow="1" AtlasIndex="0" customAnchor="0.000000 0.000000" SinusAmplitude="0.000000 0.000000 0.000000" SinusSpeed="1.000000" AngleX="0.000000" AngleY="0.000000">
										<PrimitiveParameters>
											<GFXPrimitiveParam colorFactor="1.000000 1.000000 1.000000 1.000000">
												<ENUM NAME="gfxOccludeInfo" SEL="0" />
											</GFXPrimitiveParam>
										</PrimitiveParameters>
										<ENUM NAME="anchor" SEL="1" />
										<material>
											<GFXMaterialSerializable ATL_Channel="0" ATL_Path="" shaderPath="world/_common/matshader/multitexture_1layer.msh" stencilTest="0" alphaTest="4294967295" alphaRef="4294967295">
												<textureSet>
													<GFXMaterialTexturePathSet diffuse="world/maps/{mapName.lower()}/menuart/textures/{mapName.lower()}_banner_bkg.tga" back_light="" normal="" separateAlpha="" diffuse_2="" back_light_2="" anim_impostor="" diffuse_3="" diffuse_4="" />
												</textureSet>
												<materialParams>
													<GFXMaterialSerializableParam Reflector_factor="0.000000" />
												</materialParams>
											</GFXMaterialSerializable>
										</material>
										<ENUM NAME="oldAnchor" SEL="1" />
									</MaterialGraphicComponent>
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="0.290211 0.290211" xFLIPPED="0" USERFRIENDLY="{mapName}_coach_1" MARKER="" isEnabled="1" POS2D="212.784500 663.680176" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/tpl_materialgraphiccomponent2d.tpl">
								<COMPONENTS NAME="MaterialGraphicComponent">
									<MaterialGraphicComponent colorComputerTagId="0" renderInTarget="0" disableLight="0" disableShadow="4294967295" AtlasIndex="0" customAnchor="0.000000 0.000000" SinusAmplitude="0.000000 0.000000 0.000000" SinusSpeed="1.000000" AngleX="0.000000" AngleY="0.000000">
										<PrimitiveParameters>
											<GFXPrimitiveParam colorFactor="1.000000 1.000000 1.000000 1.000000">
												<ENUM NAME="gfxOccludeInfo" SEL="0" />
											</GFXPrimitiveParam>
										</PrimitiveParameters>
										<ENUM NAME="anchor" SEL="6" />
										<material>
											<GFXMaterialSerializable ATL_Channel="0" ATL_Path="" shaderPath="world/_common/matshader/multitexture_1layer.msh" stencilTest="0" alphaTest="4294967295" alphaRef="4294967295">
												<textureSet>
													<GFXMaterialTexturePathSet diffuse="world/maps/{mapName.lower()}/menuart/textures/{mapName.lower()}_coach_1.tga" back_light="" normal="" separateAlpha="" diffuse_2="" back_light_2="" anim_impostor="" diffuse_3="" diffuse_4="" />
												</textureSet>
												<materialParams>
													<GFXMaterialSerializableParam Reflector_factor="0.000000" />
												</materialParams>
											</GFXMaterialSerializable>
										</material>
										<ENUM NAME="oldAnchor" SEL="6" />
									</MaterialGraphicComponent>
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<sceneConfigs>
							<SceneConfigs activeSceneConfig="0" />
						</sceneConfigs>
					</Scene>
				</SCENE>
			</SubSceneActor>
		</ACTORS>
		<ACTORS NAME="SubSceneActor">
			<SubSceneActor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_AUTODANCE" MARKER="" isEnabled="1" POS2D="0.000000 -0.033823" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="enginedata/actortemplates/subscene.tpl" RELATIVEPATH="world/maps/{mapName.lower()}/autodance/{mapName.lower()}_autodance.isc" EMBED_SCENE="1" IS_SINGLE_PIECE="0" ZFORCED="1" DIRECT_PICKING="1" IGNORE_SAVE="0">
				<ENUM NAME="viewType" SEL="2" />
				<SCENE>
					<Scene ENGINE_VERSION="272933" GRIDUNIT="0.500000" DEPTH_SEPARATOR="0" NEAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" FAR_SEPARATOR="1.000000 0.000000 0.000000 0.000000, 0.000000 1.000000 0.000000 0.000000, 0.000000 0.000000 1.000000 0.000000, 0.000000 0.000000 0.000000 1.000000" viewFamily="0">
						<ACTORS NAME="Actor">
							<Actor RELATIVEZ="0.000000" SCALE="1.000000 1.000000" xFLIPPED="0" USERFRIENDLY="{mapName}_autodance" MARKER="" isEnabled="1" POS2D="-0.006150 -0.003075" ANGLE="0.000000" INSTANCEDATAFILE="" LUA="world/maps/{mapName.lower()}/autodance/{mapName.lower()}_autodance.tpl">
								<COMPONENTS NAME="JD_AutodanceComponent">
									<JD_AutodanceComponent />
								</COMPONENTS>
							</Actor>
						</ACTORS>
						<sceneConfigs>
							<SceneConfigs activeSceneConfig="0" />
						</sceneConfigs>
					</Scene>
				</SCENE>
			</SubSceneActor>
		</ACTORS>
		<sceneConfigs>
			<SceneConfigs activeSceneConfig="0">
				<sceneConfigs NAME="JD_MapSceneConfig">
					<JD_MapSceneConfig name="" soundContext="" hud="0" phoneTitleLocId="4294967295" phoneImage="">
						<ENUM NAME="Pause_Level" SEL="6" />
						<ENUM NAME="type" SEL="1" />
						<ENUM NAME="musicscore" SEL="2" />
					</JD_MapSceneConfig>
				</sceneConfigs>
			</SceneConfigs>
		</sceneConfigs>
	</Scene>
</root>''')

# MainScene SGS File
with open (f'{output_folder_cache}/{mapName.lower()}_main_scene.sgs.ckd', "wb") as archive:
    archive.write(
    b'\x53\x7B\x22\x73\x65\x74\x74\x69\x6E\x67\x73\x22\x3A\x7B\x22\x5F' +
    b'\x5F\x63\x6C\x61\x73\x73\x22\x3A\x22\x4A\x44\x5F\x4D\x61\x70\x53' +
    b'\x63\x65\x6E\x65\x43\x6F\x6E\x66\x69\x67\x22\x2C\x22\x50\x61\x75' +
    b'\x73\x65\x5F\x4C\x65\x76\x65\x6C\x22\x3A\x36\x2C\x22\x6E\x61\x6D' +
    b'\x65\x22\x3A\x22\x22\x2C\x22\x74\x79\x70\x65\x22\x3A\x31\x2C\x22' +
    b'\x6D\x75\x73\x69\x63\x73\x63\x6F\x72\x65\x22\x3A\x32\x2C\x22\x73' +
    b'\x6F\x75\x6E\x64\x43\x6F\x6E\x74\x65\x78\x74\x22\x3A\x22\x22\x2C' +
    b'\x22\x68\x75\x64\x22\x3A\x30\x2C\x22\x70\x68\x6F\x6E\x65\x54\x69' +
    b'\x74\x6C\x65\x4C\x6F\x63\x49\x64\x22\x3A\x34\x32\x39\x34\x39\x36' +
    b'\x37\x32\x39\x35\x2C\x22\x70\x68\x6F\x6E\x65\x49\x6D\x61\x67\x65' +
    b'\x22\x3A\x22\x22\x7D\x7D\x00'
  )  
    
# SongDesc Actor File
with open(f"{output_folder_cache}/songdesc.act.ckd", "wb") as archive:
    archive.write(
        b'\x00\x00\x00\x01\x00\x00\x00\x00\x3F\x80\x00\x00\x3F\x80\x00\x00' +
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01' +
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' +
        b'\x00\x00\x00\x00\xFF\xFF\xFF\xFF\x00\x00\x00\x00\x00\x00\x00\x0C' +
        b'songdesc.tpl.ckd' +
        b'\x00\x00\x00\x1CD' +
        f"world/maps/{mapName.lower()}".encode() +
        b'\x2F\xE5\xF9\x0F\x80\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\xE0\x7F\xCC\x3F'
    )
  
  # End of Cache Folder
  
  # World Folder
  
  
  # Autodance Folder
    os.makedirs(f'{output_folder_world}/autodance', exist_ok=True)
    
    
    # Timeline World Folder
    os.makedirs(f'{output_folder_world}/timeline/moves/wiiu', exist_ok=True)
  
if platform in ["orbis"]:
    os.makedirs(f'{output_folder_world}/timeline/moves/orbis', exist_ok=True)
     
   
   # End of World Folder
   
   
def autoMod(mapName= str, coachCount= int, platform= str):

# Files
    input_path = f"{os.getcwd()}/input/{mapName}"
    if not os.path.exists(input_path):
        logging.info('Input folder not found!')

    Utils.CopyFile(f"{os.getcwd()}/input/{mapName}/*songdesc.tpl.ckd", f"{output_folder_cache}/songdesc.tpl.ckd")
    Utils.CopyFile(f"{os.getcwd()}/input/{mapName}/audio/*musictrack.tpl.ckd", f"{output_folder_cache}/audio/{mapName.lower()}_musictrack.tpl.ckd")
    Utils.CopyFile(f"{os.getcwd()}/input/{mapName}/cinematics/*mainsequence.tape.ckd", f"{output_folder_cache}/cinematics/{mapName.lower()}_mainsequence.tape.ckd")
    Utils.CopyFile(f"{os.getcwd()}/input/{mapName}/*.ktape.ckd", f"{output_folder_cache}/timeline/{mapName.lower()}_tml_karaoke.ktape.ckd")
    Utils.CopyFile(f"{os.getcwd()}/input/{mapName}/autodance/*{mapName}.ogg", f"{output_folder_world}/autodance/{mapName.lower()}.ogg")
    Utils.CopyFile(f"{os.getcwd()}/input/{mapName}/*.dtape.ckd", f"{output_folder_cache}/timeline/{mapName.lower()}_tml_dance.dtape.ckd")
    
if platform in ["ORBIS", "DURANGO", "PROSPERO"]:
    # Move ONLY .hd.mpd.ckd for orbis, durango and prospero
    print(f"Moving .hd.mpd.ckd for {platform}...")
    Utils.CopyFile(f"{os.getcwd()}/input/{mapName}/videoscoach/hd/*.hd.mpd.ckd", f"{output_folder_cache}/videoscoach/{mapName.lower()}.hd.mpd.ckd")
    
if platform in ["PC", "NX", "WIIU"]:
    # Move ONLY .mpd.ckd for pc, nx and wiiu
    print(f"Moving .mpd.ckd for {platform}...")
    Utils.CopyFile(f"{os.getcwd()}/input/{mapName}/videoscoach/*.mpd.ckd", f"{output_folder_cache}/videoscoach/{mapName.lower()}.mpd.ckd")

# Cook pictos
print("Cooking pictos...")
Utils.CookPictos(f"{os.getcwd()}/input/{mapName}/timeline/pictos", f"{output_folder_cache}/timeline/pictos", platform)
# Now copy msm
print("Moving MSMs...", end="\n")
msm_path = f"{output_folder_world}/timeline/moves/wiiu/"
os.makedirs(msm_path, exist_ok=True)
for msm in os.listdir(f"{os.getcwd()}/input/{mapName}/timeline/moves/wiiu"):
    if msm.endswith(".msm"):
            shutil.copy(f"{os.getcwd()}/input/{mapName}/timeline/moves/wiiu/{msm}", msm_path)

    # Now copy gesture and msm
    if platform == "ORBIS":
        print("Moving MSMs and Gestures for Orbis...", end="\n")
        gesture_path = f"{output_folder_world}/timeline/moves/orbis/"
        os.makedirs(gesture_path, exist_ok=True)
        for gesture in os.listdir(f"{os.getcwd()}/input/{mapName}/timeline/moves/orbis"):
            if gesture.endswith(".gesture") or gesture.endswith(".msm"):
                shutil.copy(f"{os.getcwd()}/input/{mapName}/timeline/moves/orbis/{gesture}", gesture_path)
    
# Sequence
mainscenegen(mapName=mapName, coachCount=coachCount, platform=platform)
autoMod(mapName=mapName, coachCount=coachCount, platform=platform)