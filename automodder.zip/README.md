

                                                                ---------------------------------------------------------------------
                                                                             Welcome to JDU Automodder by Lunn !
                                                                       Make PartyTime Online mainscenes in 5 minutes!
                                                                ---------------------------------------------------------------------
																
																
																put each file in your place: 
																
																songdesc.tpl.ckd > input\mapName 
																mapName_musictrack.tpl.ckd > input\mapName\audio
																mapName.ogg (autodance audio) > input\mapName\autodance
																mapName_mainsequence.tape.ckd > input\mapName\cinematics
																mapName_tml_dance.dtape.ckd > input\mapName\timeline
																mapName_tml_karaoke.ktape.ckd > input\mapName\timeline
																mapName.hd.mpd.ckd > input\mapName\videoscoach\hd
																mapName.mpd.ckd > input\mapName\videoscoach
																pictos in png > input\mapName\timeline\pictos
																msm > input\mapName\timeline\moves\wiiu
																gesture > input\mapName\timeline\moves\orbis
																
																note:
																This tool generate mpd, but i didn't test, but i recommend
																you use ibra's nohud maker/mpd maker!
																
																WARNING!
																You need .NET Core 3.1.0 to cook PS5 texture! 
																
																download link: https://download.visualstudio.microsoft.com/download/pr/f6fb21ca-cbf8-41a0-87b9-84225ae485cd/7dcd7ed94e6614098edd2f9832bceeee/dotnet-sdk-3.1.100-win-x86.exe
																
																
																